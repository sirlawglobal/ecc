const hompepageUrl = 'http://dgn128.pro';

function addUserData(){
    var modals = document.querySelector('.modals');
    var modalContent = `
    

    <div id="myModal" class="modal-container">
        <div class="userdata-modal-content">
            
            <div class="add-text-header">
                <h3></h3>
                    <h3>Add User Data</h3>
                    <span onclick="closeModal()" class="close">&times;</span>
                </div>
                <div class="userdata-options-container">
                    <div class="userdata-options">
                        <img id="userdata-option-1" class="userdata-image" src="${hompepageUrl}/assets/images/green-mark.png" alt="" />
                        <h3 onclick="changeUserDataContent(pinContent)" class="userdata-option-text" id="userdata-option-text-1" >Pin</h3>
                    </div>
                    <div class="userdata-options">
                        <img id="userdata-option-1" class="userdata-image" src="${hompepageUrl}/assets/images/green-mark.png" alt="" />
                        <h3 onclick="changeUserDataContent(biodataContent)" class="userdata-option-text" id="userdata-option-text-1" >Biodata</h3>
                    </div>
                    <div class="userdata-options">
                        <img id="userdata-option-1" class="userdata-image" src="${hompepageUrl}/assets/images/green-mark.png" alt="" />
                        <h3 onclick="changeUserDataContent(locationContent)" class="userdata-option-text" id="userdata-option-text-1" >Location</h3>
                    </div>
                    <div class="userdata-options">
                        <img id="userdata-option-1" class="userdata-image" src="${hompepageUrl}/assets/images/green-mark.png" alt="" />
                        <h3 onclick="changeUserDataContent(povertyStatusContent)" class="userdata-option-text" id="userdata-option-text-1" >Poverty Status</h3>
                    </div>
                    <div class="userdata-options">
                        <img id="userdata-option-1" class="userdata-image" src="${hompepageUrl}/assets/images/green-mark.png" alt="" />
                        <h3 onclick="changeUserDataContent(idContent)" class="userdata-option-text" id="userdata-option-text-1" >ID</h3>
                    </div>
                </div>
                <hr class="hr">
               <div id="user-data-content-container" class="user-data-content-container">
                    <div class="content-header-container">
                        <h4 id="content-header" class="content-header">Generate Your Pin</h4>
                    </div>
                    <div class="generate-pin-container">
                        <p class="generate-text">Click the button below to generate your pin</p>
                 
                            <form id="form" class="generate-form">
                                <div class="form_element">
                                    <label for="Donor">Pin</label>
                                    <input class="modal-input" type="text" id="generated-pin" />
                                </div>
                            <div class="modal-button-container">
                                <button type="button" class="generate-button" onclick="saveProgramData()"       id="save-btn">Generate</  button>  
                            </div>
                        
                        </form>

                    </div>
                </div>
      

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function chooseId(entry){
    alert(2)
}




const pinContent = `
      <div class="content-header-container">
                        <h4 id="content-header" class="content-header">Generate Your Pin</h4>
                    </div>
                    <div class="generate-pin-container">
                        <p class="generate-text">Click the button below to generate your pin</p>
                 
                            <form id="form" class="generate-form">
                                <div class="form_element">
                                    <label for="Donor">Pin</label>
                                    <input class="modal-input" type="text" id="generated-pin" />
                                </div>
                            <div class="modal-button-container">
                                <button type="button" class="generate-button" onclick="saveProgramData()"       id="save-btn">Generate</  button>  
                            </div>
                        
                        </form>

                    </div>
`
const biodataContent = `
     <div class="content-header-container">
                        <h4 id="content-header" class="content-header">BioData</h4>
                    </div>
                    <div class="generate-pin-container">
                            <form id="form" class="biodata-form">
                                <div class="three-forms">
                                    <div class="form_element">
                                        <label class="form-label" for="first_name">First Name</label>
                                        <input class="modal-input" type="text" id="first_name" />
                                    </div>
                                    <div class="form_element">
                                        <label class="form-label" for="last_name">Last Name</label>
                                        <input class="modal-input" type="text" id="last_name" />
                                    </div>
                                    <div class="form_element">
                                        <label class="form-label" for="age">Age</label>
                                        <input class="modal-input" type="number" id="age" />
                                    </div>
                                </div>
                                <div class="three-forms">
                                    <div class="form_element">
                                        <label class="form-label" for="gender">Gender</label>
                                      
                                        <select class="modal-input" id="gender">
                                            <option value="">Choose a gender</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                        </select>
                                    </div>
                                    <div class="form_element">
                                        <label class="form-label" for="marital_status">Marital Status</label>
                                         <select class="modal-input"  id="marital_status">
                                            <option value="">Choose a Marital Status</option>
                                            <option value="Single">Single</option>
                                            <option value="Married">Married</option>
                                            <option value="Widowed">Widowed</option>
                                            <option value="Divorced">Divorced</option>
                                            <option value="Separated">Separated</option>
                                        </select>
                                    </div>
                                

                                </div>

                                <div class="indicator margin-top">
                                 
                                    <img src="../assets/images/indicator-image.png" alt="" class="indicator-image">
                                </div>

                                   <div class="three-forms">
                                        <div class="form_element">
                                            <label class="form-label" for="gender">Disability</label>
                                        
                                            <select class="modal-input" id="disability">
                                                <option value="">Are you disabled?</option>
                                                <option value="Male">Yes</option>
                                                <option value="Female">No</option>
                                            </select>
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="marital_status">Economic Activities</label>
                                            <select class="modal-input"  id="economic_activities">
                                                <option value="">Choose an Activity</option>
                                                <option value="Unemployed">Unemployed</option>
                                                <option value="Part-time Employed">Part-time Employed</option>
                                                <option value="Full-time Employed">Full-time Employed</option>
                                                <option value="Self Employed/Business Owner">Self Employed/Business Owner</option>
                                    
                                            </select>
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="marital_status">Family Support</label>
                                            <select class="modal-input"  id="marital_status">
                                                <option value="">Level Of Support</option>
                                                <option value="No Support">No Support</option>
                                                <option value="Limited Support">Limited Support</option>
                                
                                            </select>
                                        </div>
                                    </div>
                                                    
                            <div class="modal-button-container margin-bottom">
                                <button type="button" class="generate-button" onclick="saveProgramData()" id="save-btn">
                                    Save
                                </button>  
                            </div>
                        
                        </form>

                    </div>
`
const locationContent = `
         <div class="content-header-container">
                        <h4 id="content-header" class="content-header">Location</h4>
                    </div>
                    <div class="generate-pin-container">
                            <form id="form" class="biodata-form">
                                <div class="three-forms">
                                    <div class="form_element">
                                        <label class="form-label" for="house_number">House Number</label>
                                        <input class="modal-input" type="text" id="house_number" />
                                    </div>
                                    <div class="form_element">
                                        <label class="form-label" for="street">Street</label>
                                        <input class="modal-input" type="text" id="street" />
                                    </div>
                                    <div class="form_element">
                                        <label class="form-label" for="area_community">Area/Community</label>
                                        <input class="modal-input" type="number" id="area_community" />
                                    </div>
                                </div>
                                <div class="three-forms">
                                    <div class="form_element">
                                        <label class="form-label" for="city_village">City/Village</label>
                                        <input class="modal-input" type="number" id="city_village" />
                                    </div>
                                   
                                

                                </div>

                               
                                                    
                            <div class="modal-button-container margin-bottom">
                                <button type="button" class="generate-button" onclick="saveProgramData()" id="save-btn">
                                    Save
                                </button>  
                            </div>
                        
                        </form>

                    </div>
`
const povertyStatusContent = `
      <div class="content-header-container">
                        <h4 id="content-header" class="content-header">Poverty Status</h4>
                    </div>
                    <div class="generate-pin-container">
                            <form id="form" class="biodata-form">
                                <div class="three-forms">
                               
                                    <div class="poverty-column">
                                        <h3 class="poverty-heading">Business Activity</h3>
                                        <div class="form_element">
                                            <label class="form-label" for="nature_type_of_business">Nature/ Type of Business</label>
                                            <input class="modal-input" type="text" id="nature_type_of_business" />
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="size_of_business">Size of Business (Estimated Value)</label>
                                            <input class="modal-input" type="text" id="size_of_business" />
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="location_of_business">Location of  Business</label>
                                            <input class="modal-input" type="text" id="location_of_business" />
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="daily_income">Daily Income</label>
                                            <input class="modal-input" type="text" id="daily_income" />
                                        </div>
                                    </div>
                                   
                                     <div class="poverty-column">
                                        <h3 class="poverty-heading">Family</h3>
                                        <div class="form_element">
                                            <label class="form-label" for="marital_status">Marital Status</label>
                                            <select class="modal-input"  id="marital_status">
                                                <option value="">Choose a Marital Status</option>
                                                <option value="Single">Single</option>
                                                <option value="Married">Married</option>
                                                <option value="Widowed">Widowed</option>
                                                <option value="Divorced">Divorced</option>
                                                <option value="Separated">Separated</option>
                                            </select>
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="size_of_business">Size of Business (Estimated Value)</label>
                                            <input class="modal-input" type="text" id="size_of_business" />
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="number_of_children">Number of children under 20 years</label>
                                            <input class="modal-input" type="text" id="number_of_children" />
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="age_of_spouse">Age of Spouse</label>
                                            <input class="modal-input" type="text" id="age_of_spouse" />
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="nature_of_occupation_spouse">Nature of occupation of spouse</label>
                                            <input class="modal-input" type="text" id="nature_of_occupation_spouse" />
                                        </div>
                                    </div>
                                     <div class="poverty-column">
                                        <h3 class="poverty-heading">Dwelling Place</h3>
                                        <div class="form_element">
                                            <label class="form-label" for="own_home">Own home or rent</label>
                                            <input class="modal-input" type="text" id="own_home" />
                                        </div>
                                        <div class="form_element">
                                            <label class="form-label" for="size_of_dwelling">Size of dwelling place ( Number of rooms)</label>
                                            <input class="modal-input" type="text" id="size_of_dwelling" />
                                        </div>
                                       

                                    </div>
                                </div>
                                <div class="three-forms">
                               
                                    <div class="poverty-column">
                                        <h3 class="poverty-heading">Nutrition</h3>
                                        <div class="form_element">
                                            <label class="form-label" for="nature_type_of_business">Main type Of Meal</label>
                                            <input class="modal-input" type="text" id="nature_type_of_business" />
                                        </div>
                                    </div>
                                   
                                     <div class="poverty-column">
                                        <h3 class="poverty-heading">Level Of Formal Education</h3>
                                        <div class="form_element">
                                            <label class="form-label" for="marital_status">Education</label>
                                            <select class="modal-input"  id="marital_status">
                                                <option value="">Choose a Level of Education</option>
                                                <option value="Non-Primary">Non-Primary</option>
                                                <option value="Half-Primary">Half-Primary</option>
                                                <option value="Full-Primary">Full-Primary</option>
                                                <option value="Half-Secondary">Half-Secondary</option>
                                            </select>
                                        </div>
                                       
                                    </div>
                                     <div class="poverty-column">
                                        <h3 class="poverty-heading">Health Status</h3>
                                        <div class="form_element">
                                            <label class="form-label" for="major_illiness">Any major illness</label>
                                            <input class="modal-input" type="text" id="major_illiness" />
                                        </div>
                                     

                                    </div>
                                </div>

                               
                                                    
                            <div class="modal-button-container margin-bottom">
                                <button type="button" class="generate-button" onclick="saveProgramData()" id="save-btn">
                                    Save
                                </button>  
                            </div>
                        
                        </form>

                    </div>
`
const idContent = `
      <div class="content-header-container">
                        <h4 id="content-header" class="content-header">ID</h4>
                    </div>
                    <div class="generate-pin-container">
                            <form id="form" class="biodata-form">
                                <div class="two-forms margin-top">
                                        <div class="id-form">
                                            <input class="modal-input" name="id" type="radio"  />
                                            <label class="form-label" for="nin">NIN(National Identification Number)</label>
                                          
                                        </div>
                                        <div class="form-nin">
                                            <p class="id-label text-center" >Please Enter Your NiN Below</p>
                                            <div class="form_element">
                                                <label class="form-label" for="nin">NIN</label>
                                                <input class="modal-input" type="text" id="nin" />
                                            </div>
                                        </div>
                                </div>
                                <div class="two-forms margin-top">
                               
                 
                                        
                                        <div class="id-form">
                                            <input name="id" class="modal-input" type="radio"  />
                                            <label class="form-label" for="drivers_license">Driver's License</label>
                                        
                                        </div>

                                        <div class="form-nin">
                                            <p class="id-label text-center" >Please Enter Your Driver's License Below</p>
                                            <div class="form_element">
                                                <label class="form-label" for="nin">Driver's License</label>
                                                <input class="modal-input" type="text" id="drivers_license" />
                                            </div>
                                            <div class="double-forms ">
                                                <div class="form_element">
                                                    <label class="form-label" for="nin">Issue Date</label>
                                                    <input class="modal-input" type="text" id="drivers_license" />
                                                </div>
                                                <div class="form_element">
                                                    <label class="form-label" for="nin">Expiry Date</label>
                                                    <input class="modal-input" type="text" id="drivers_license" />
                                                </div>
                                            </div>
                                        </div>
            
                                   
                                   
                                </div>
                                <div class="two-forms margin-top">
                               
                 
                                        
                                        <div class="id-form">
                                            <input onchange="chooseId("voters_card")" name="id" class="modal-input" type="radio" id="voters_card" />
                                            <label class="form-label" for="voters_card">Voters Card</label>
                                        
                                        </div>
                                         <div class="form-nin">
                                            <p class="id-label text-center" >Please Enter Your Voters Card Details Below</p>
                                            <div class="form_element">
                                                <label class="form-label" for="nin">Voters Card</label>
                                                <input class="modal-input" type="text" id="nin" />
                                            </div>
                                        </div>
                         
                                   
                                   
                                </div>
                               

                               
                                                    
                            <div class="modal-button-container margin-bottom">
                                <button type="button" class="generate-button" onclick="saveProgramData()" id="save-btn">
                                    Save
                                </button>  
                            </div>
                        
                        </form>

                    </div>
`

function changeUserDataContent(content){

    const contentContainerId = document.getElementById("user-data-content-container");
    if(contentContainerId){
        contentContainerId.innerHTML = content;
    }
}

