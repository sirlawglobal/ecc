var formData = new FormData();
formData.append('donor', donor);
formData.append('item', item);
formData.append('amount', amount);
formData.append('date', date);
formData.append('receiptNo', receiptNo);
formData.append('image', chosen_file2);



  // $sql = "INSERT INTO ProgramData(project_name, project_manager, client, date) VALUE('{$project_name}', '{$project_manager}', '{$client}', '{$date}') ";

            // $sql1 = "INSERT INTO `ProgramData1`( `donor`, `item`, `amount`, `date`, `receiptNo`, `receipt_Image`) VALUES ('donor','item','amount','date','receiptNo','image');