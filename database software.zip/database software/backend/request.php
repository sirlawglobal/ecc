<?php

error_reporting(E_ALL);           
ini_set('display_errors', 1);   

    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST');
    header("Access-Control-Allow-Headers: X-Requested-With");

    include('./config/database.php');

    $db = new Database();

    if(isset($_GET['function'])){
        $function = $_GET['function'];

        if($function == "admin-login"){
            //login as an admin
            $user = $db->adminLogin($_POST['email'], $_POST['password']);
            if($user){
                echo json_encode(['user'=>$user]);
            }else{
                echo json_encode(['error'=>'Wrong username or password']);
            }
        }

//programData
        if($function == "save-ProgramData"){
            $programData = $db->saveProgramData($_POST,$_FILES);
            if($programData){
                echo json_encode(['programData'=>$programData]);
            }else{
                echo json_encode(['error'=>'error in saving']);
            }
        }
        if($function == "get-ProgramData"){
            $programData = $db->getProgramData();
            if($programData){
                echo json_encode(['programData'=>$programData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }
        if($function == "update-ProgramData"){
            $programData = $db->updateProgramData($_POST,$_FILES);
            if($programData){
                echo json_encode(['programData'=>$programData]);
            }else{
                echo json_encode(['error'=>'error in fetching']);
            }
        }

        if($function == 'delete-ProgramData'){
            $delete = $db->deleteProgramData($_POST);
            if($delete){
                echo json_encode(['success'=>"Contact deleted!"]);
            }else{
                echo json_encode(['error'=>'An error occured!']);
            }
        }

        
    }

   

?>