<?php 


    class Database {
        protected $host = "localhost";
        protected $user = "dgn128_new";
        protected $pass = "N!I(VPRjL+LO";
        protected $database = "dgn128_database_software";

        public $connect;

        public function __construct(){
            $this->connect = new mysqli($this->host, $this->user, $this->pass, $this->database);
            if($this->connect->connect_error){
                echo "Sorry, couldn't connect to the database".$this->connect->connect_error;
            }else{
                $this->createAdminLogin();
            }
        }

        public function query($sql){
            $query = $this->connect->query($sql);
            return $query;
        }

        public function createAdminLogin(){
            $email = "admin@database.com";
            $password = "1224";
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            $sql = "INSERT INTO admins(email, password) VALUES('{$email}', '{$hashed_password}')";
            $query = $this->connect->query($sql);
            return $query;
            
        }

        public function adminLogin($email, $password){
            $sql = "SELECT * FROM admins WHERE email = '$email'";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $row = $query->fetch_assoc();
                $verify_password = password_verify($password, $row['password']);
                if($verify_password){
                    return $row;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
       
        //programm data
        public function saveProgramData($data , $files){

            $donor = isset($data['donor']) ? $this->connect->real_escape_string($data['donor']) : null;

            $item = isset($data['item']) ? $this->connect->real_escape_string($data['item']) : null;

            $amount = isset($data['amount']) ? $this->connect->real_escape_string($data['amount']) : null;

            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;

            $receiptNo = isset($data['receiptNo']) ? $this->connect->real_escape_string($data['receiptNo']) : null;


            $image = '';
            if(isset($files['image'])){
                $upload_folder = "/home/dgn128/public_html/uploads/";
                // $upload_folder = "./uploads/"
                $file = $files['image'];
                $encrypted_name = uniqid(). '-' .$file['name'];
                $directory = $upload_folder.$encrypted_name;

                if(move_uploaded_file($file['tmp_name'], $directory)){
                    $image = $encrypted_name;
                } else {
                    return false;
                }
                }

              $sql = "INSERT INTO ProgramData_table (donor, item, amount, date, receiptNo, receipt_Image) 
            VALUES ('$donor', '$item', '$amount', '$date', '$receiptNo', '$image')";

            $query = $this->connect->query($sql);
            return $query;
        }

        public function getProgramData(){
            $sql = "SELECT * FROM ProgramData_table ORDER BY id DESC";
            $query = $this->connect->query($sql);
            if($query->num_rows > 0){
                $data = [];
                while($row = $query->fetch_assoc()){
                    array_push($data, $row);
                }
                return $data;
            }else{
                return false;
            }
        }
           
        public function updateProgramData($data , $files){
            

            $programDataId = isset($data['programDataId']) ? $this->connect->real_escape_string($data['programDataId']) : null;

            $donor = isset($data['donor']) ? $this->connect->real_escape_string($data['donor']) : null;

            $item = isset($data['item']) ? $this->connect->real_escape_string($data['item']) : null;

            $amount = isset($data['amount']) ? $this->connect->real_escape_string($data['amount']) : null;

            $date = isset($data['date']) ? $this->connect->real_escape_string($data['date']) : null;

            $receiptNo = isset($data['receiptNo']) ? $this->connect->real_escape_string($data['receiptNo']) : null;


            $image = '';
            if(isset($files['image'])){
                $upload_folder = "/home/dgn128/public_html/uploads/";
                // $upload_folder = "./uploads/"
                $file = $files['image'];
                $encrypted_name = uniqid(). '-' .$file['name'];
                $directory = $upload_folder.$encrypted_name;

                if(move_uploaded_file($file['tmp_name'], $directory)){
                    $image = $encrypted_name;
                } else {
                    return false;
                }
                }

                $sql = "UPDATE ProgramData_table SET donor = '$donor', item= '$item', amount = '$amount', date = '$date', receiptNo= '$receiptNo', receipt_Image = '$image' WHERE id = '$programDataId'";
                $query = $this->connect->query($sql);
                if($query){
                    return true;
                }else{
                    return false;
                }


            $query = $this->connect->query($sql);
            return $query;
        }
        
        public function deleteProgramData($data){
            $programDataId = $data['programDataId'];
            $sql = "DELETE FROM ProgramData_table WHERE id = '$programDataId'";
            $query = $this->connect->query($sql);
            if($query){
                return true;
            }else{
                return false;
            }
        }
        

        





    }

?>