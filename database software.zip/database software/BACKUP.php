<?php

// CREATE TABLE disbursements (
//     id INT AUTO_INCREMENT PRIMARY KEY,
//     receiver VARCHAR(255),
//     pin VARCHAR(255),
//     date DATE
// );

// CREATE TABLE disbursement_items (
//     id INT AUTO_INCREMENT PRIMARY KEY,
//     disbursement_id INT,
//     item VARCHAR(255),
//     quantity INT,
//     FOREIGN KEY (disbursement_id) REFERENCES disbursements(id) ON DELETE CASCADE
// );

// Assuming a POST request is made with function=save-disburseData
// if (isset($_GET['function']) && $_GET['function'] == 'save-disburseData') {

//     // Get form data from POST request
//     $receiver = $_POST['receiver'];
//     $pin = $_POST['pin'];
//     $date = $_POST['date'];

//     // Create arrays to store the items and quantities
//     $items = [];
//     $quantities = [];

//     // Retrieve all items and quantities from the form
//     foreach ($_POST as $key => $value) {
//         if (strpos($key, 'item[') !== false) {
//             $items[] = $value;
//         }
//         if (strpos($key, 'quantity[') !== false) {
//             $quantities[] = $value;
//         }
//     }

//     // Now you have $receiver, $pin, $date, $items (array), and $quantities (array)
//     // Example: Save to the database using prepared statements

//     // Assuming you have a database connection
//     // Example using MySQLi (assuming the connection is $conn)
//     $stmt = $conn->prepare("INSERT INTO disbursements (receiver, pin, date) VALUES (?, ?, ?)");
//     $stmt->bind_param("sss", $receiver, $pin, $date);

//     // Execute the statement to save the general information
//     if ($stmt->execute()) {
//         $disbursementId = $conn->insert_id; // Get the last inserted ID for the disbursement

//         // Loop through items and quantities to save them in the items table
//         $stmtItems = $conn->prepare("INSERT INTO disbursement_items (disbursement_id, item, quantity) VALUES (?, ?, ?)");
//         foreach ($items as $index => $item) {
//             $quantity = $quantities[$index];
//             $stmtItems->bind_param("isi", $disbursementId, $item, $quantity);
//             $stmtItems->execute();
//         }

//         // Success response
//         echo json_encode(['status' => 'success', 'message' => 'Record saved!']);
//     } else {
//         // Error handling
//         echo json_encode(['status' => 'error', 'message' => 'Error saving record.']);
//     }

//     // Close the statements
//     $stmt->close();
//     $stmtItems->close();
//     // Close database connection
//     $conn->close();
// }





// Assuming you have a database connection $conn

// Fetch data with JOIN query
$sql = "SELECT d.id as disbursement_id, d.receiver, d.pin, d.date, i.item, i.quantity 
        FROM disbursements d 
        LEFT JOIN disbursement_items i ON d.id = i.disbursement_id";
$result = $conn->query($sql);

// Initialize an empty array to store the results
$response = [];

// Process the result
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        // Group the data by disbursement ID
        if (!isset($response[$row['disbursement_id']])) {
            $response[$row['disbursement_id']] = [
                'disbursement_id' => $row['disbursement_id'],
                'receiver' => $row['receiver'],
                'pin' => $row['pin'],
                'date' => $row['date'],
                'items' => []
            ];
        }

        // Add each item to the corresponding disbursement
        $response[$row['disbursement_id']]['items'][] = [
            'item' => $row['item'],
            'quantity' => $row['quantity']
        ];
    }

    // Convert response to indexed array for cleaner JSON
    $response = array_values($response);

    // Send the response as JSON
    echo json_encode(['status' => 'success', 'data' => $response]);
} else {
    // No records found
    echo json_encode(['status' => 'error', 'message' => 'No records found']);
}

// Close the database connection
$conn->close();
?>
