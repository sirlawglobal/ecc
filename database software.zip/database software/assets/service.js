const openModal = () => {
    const modal = document.getElementById("myModal")
    if(modal){
        modal.style.display = 'block'
        }
}


function closeModal(){
    const modal = document.getElementById("myModal")
    if(modal){
        modal.style.display = 'none';
    }
}

function toggleZoom() {
    const image = document.querySelector('.signature-image');
    image.classList.toggle('zoom-out');
}


// function showOptions(indexNumber){
//     optionIndexNumber = indexNumber;
//     var optionCard = document.getElementById(indexNumber);
//     optionCard.style.display = 'flex';
// }

// function showOptions(indexNumber) {
//     var optionCard = document.getElementById(indexNumber);
    
//     // Check if element exists
//     if (optionCard) {
//         // Toggle the display of the dropdown
//         if (optionCard.style.display === 'none' || optionCard.style.display === '') {
//             optionCard.style.display = 'flex'; // Show the dropdown
//         } else {
//             optionCard.style.display = 'none'; // Hide the dropdown
//         }
//     } else {
//         console.error(`Element with id ${indexNumber} not found`);
//     }
// }

function showOptions(indexNumber) {
    // Close any open dropdowns first
    var dropdowns = document.querySelectorAll('.options-dropdown');
    dropdowns.forEach(function(dropdown) {
        if (dropdown.id !== indexNumber) {
            dropdown.style.display = 'none'; // Hide other dropdowns
        }
    });
    
    var optionCard = document.getElementById(indexNumber);
    
    // Check if element exists
    if (optionCard) {
        // Toggle the display of the dropdown
        if (optionCard.style.display === 'none' || optionCard.style.display === '') {
            optionCard.style.display = 'flex'; // Show the dropdown
        } else {
            optionCard.style.display = 'none'; // Hide the dropdown
        }
    } else {
        console.error(`Element with id ${indexNumber} not found`);
    }
}

const hompepageUrl2 = 'http://dgn128.pro';
var modals 

//programme data
var programData =null;
var chosen_file2 =null;
function onFileSelect2(event){
    chosen_file2 = event.target.files[0];
    var url = URL.createObjectURL(chosen_file2);
    var imageContent = `<img src="${url}" class="preview-image" style="width: 400px; height: 40px;" />`;
    var previewContainer = document.getElementById('preview');
    var motherPreviewContainer = document.getElementById('mother_preview');
    var btnSelect = document.getElementById('sltBtn');
    previewContainer.innerHTML = imageContent;
    previewContainer.style.display="block";
    motherPreviewContainer.style =`flex-direction:column;justify-content: flex-start;`
    btnSelect.innerHTML="Change Attachment?Click again";
}
function addProgramData(){
    var modals = document.querySelector('.modals');
    var modalContent = `
    
    <style>
        input{
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        
        }
            

        .modal-container{
            display: none; 
            position: fixed; /* Fixed position */
            z-index: 12000; /* Make sure it appears on top of everything */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); /* Black background with opacity */
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            /* padding: 20px; */
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 500px;
            max-width: 458px;
            /* overflow-x: scroll;
            overflow-y: scroll; */
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
        background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .add-text > h3 {
            color: #FFF;
            font-family: Archivo;
            font-size: 24px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 28.8px */
            text-align: center;
        }

        .nav-btn {
        display: flex;
        width: 110px;
        height: 40px;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background: #097B48;
        border: 0;
        color: #FFF;
        font-family: Roboto;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        cursor: pointer;
        }

        .save-button{
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 19.2px */
            border: 0;
            margin-left: 110px;
            margin-top: 20px;
        }

        .add-recept{
        /* padding:10px; */
        border-color: transparent;
        background-color: transparent;
        color: #097B48;
        font-family: Inter;
        cursor: pointer;
        }

    .form_element{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    form{
        padding: 20px;
        font-family: Inter;
    }
</style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            
            <div class="add-text-header">
            <h3></h3>
                <h3>Add </h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
        <form id="form">
                       

                       <div class="form_element">
                                <label for="Donor">Name of Donor</label>
                                <input type="text" id="Donor" required />
                        </div>
                       <div class="form_element">
                                <label for="Item">Item</label>
                                <input type="text" id="Item" required />
                        </div>
                       <div class="form_element">
                                <label for="Amount">Amount</label>
                                <input type="text" id="Amount" required />
                        </div>
                       <div class="form_element">
                                <label for="Date">Date</label>
                                <input type="date" id="Date" required />
                        </div>
                       <div class="form_element">
                                <label for="ReceiptNo">Receipt/Cheque Number</label>
                                <input type="text" id="ReceiptNo" required />
                        </div>
                       
                        <input type="file" id="signatureUpload" accept="image/*" style="display:none" onchange="onFileSelect2(event)">
                        
                        <div style="display:flex;  " id="mother_preview">
                            <button type='button' class="add-recept" id="sltBtn" onclick="document.getElementById('signatureUpload').click()" >Add Attachment</button> 

                            <span id="preview"></span>
                        </div>

                    <button type="button" class="save-button" onclick="saveProgramData()" id="save-btn">Save</button>  
    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveProgramData(){
    var savebtn = document.getElementById('save-btn');
    var form = document.getElementById('form');
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;
     var modals = document.querySelector('.modals');
    const donor = document.getElementById('Donor').value;
    const item = document.getElementById('Item').value;
    const amount = document.getElementById('Amount').value;
    const date = document.getElementById('Date').value;
    const receiptNo = document.getElementById('ReceiptNo').value;
    
    var formData = new FormData();
    formData.append('donor', donor);
    formData.append('item', item);
    formData.append('amount', amount);
    formData.append('date', date);
    formData.append('receiptNo', receiptNo);
    formData.append('image', chosen_file2);
   
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        // for(var modal of modals){
        //     modal.style.display = 'none';
        // }

        // for(var form of forms){
        //     form.reset();
        // }
        form.reset();
        modals.style.display = 'none';
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Success', "Record saved!", 'success');
        getProgramData();
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occured, try again!", 'error');
    }

    xhttp.open("POST", '../backend/request.php?function=save-ProgramData', true);
   
    console.log("formData",formData )
    xhttp.send(formData);
}

function getProgramData(){
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        programData = response.programData;
        loopProgramData(programData);
    }

    xhttp.open("GET", '../backend/request.php?function=get-ProgramData', true);
    xhttp.send();
}

function loopProgramData(data){
    var container = document.getElementById('ProgramTbody');
    var tr = "";
    var counter = 0;
    if(data && data.length > 0){
        for(var i=0; i < data.length; i++){
        counter++;
        tr += `
                    <tr class="ehi-tbody-tr">
                            
                            <td class="ehi-td">${(counter)}</td>
                            <td class="ehi-td">${(data[i].donor)}</td>
                            <td class="ehi-td">${(data[i].item)}</td>
                            <td class="ehi-td">${(data[i].amount)}</td>
                            <td class="ehi-td">${(data[i].date)}</td>
                            
                            <td class="ehi-td flex-center">
                    <div style="position:relative;">
                            <!-- Button to show the dropdown -->
                            <button onclick="showOptions(${i})" class="three" style="cursor: pointer;background-color: transparent;border-color: transparent;outline: transparent;">
                                <img src="../assets/images/three-options.png" alt="" class="three-options">
                            </button>

                            <!-- Dropdown with dynamic ID based on 'i' -->
                            <div id="${i}" class="options-dropdown" style="display:none; right: 5px; position: absolute;">
                                <button onclick="editProgramData(${data[i].id})" class="openModalBtnEdit option-button">
                                    <img src="/assets/images/edit.png"/> Edit
                                </button>   

                                <button onclick="viewProgramData(${data[i].id})" class="openModalBtnView option-button">
                                    <img src="/assets/images/view.png"/> View
                                </button>   

                                <button onclick="deleteProgramData(${data[i].id})" class="option-button">
                                    <img src="/assets/images/delete.png"/> Delete
                                </button>   
    </div>
</div>


                            </div>
                            </td>
                        </tr>
        `;
        if(container){
            container.innerHTML = tr;
        }
    }
    }else{
        if(container){
            container.innerHTML = "No data yet!";
        }
    }
    
}
getProgramData();

function editProgramData(programDataId){
console.log("programDataId",programDataId)

    var data = programData.find((programDatum)=>{
        return programDatum.id == programDataId
    });

    var modals = document.querySelector('.modals');
    var modalContent = `
    
    <style>
        input{
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        
        }
            

        .modal-container{
            display: none; 
            position: fixed; /* Fixed position */
            z-index: 12000; /* Make sure it appears on top of everything */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); /* Black background with opacity */
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            /* padding: 20px; */
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 500px;
            max-width: 458px;
            /* overflow-x: scroll;
            overflow-y: scroll; */
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
        background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .add-text > h3 {
            color: #FFF;
            font-family: Archivo;
            font-size: 24px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 28.8px */
            text-align: center;
        }

        .nav-btn {
        display: flex;
        width: 110px;
        height: 40px;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background: #097B48;
        border: 0;
        color: #FFF;
        font-family: Roboto;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        cursor: pointer;
        }

        .save-button{
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 19.2px */
            border: 0;
            margin-left: 110px;
            margin-top: 20px;
        }

        .add-recept{
        /* padding:10px; */
        border-color: transparent;
        background-color: transparent;
        color: #097B48;
        font-family: Inter;
        cursor: pointer;
        }

    .form_element{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    form{
        padding: 20px;
        font-family: Inter;
    }
</style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            
            <div class="add-text-header">
            <h3></h3>
                <h3>Edit </h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
        <form id="form">
                       

                       <div class="form_element">
                                <label for="Donor">Name of Donor</label>
                                <input type="text" id="Donor" required value="${data.donor}"/>
                        </div>
                       <div class="form_element">
                                <label for="Item">Item</label>
                                <input type="text" id="Item" required value="${data.item}"/>
                        </div>
                       <div class="form_element">
                                <label for="Amount">Amount</label>
                                <input type="text" id="Amount" required  value="${data.amount}"/>
                        </div>
                       <div class="form_element">
                                <label for="Date">Date</label>
                                <input type="date" id="Date" required  value="${data.date}"/>
                        </div>
                       <div class="form_element">
                                <label for="ReceiptNo">Receipt/Cheque Number</label>
                                <input type="text" id="ReceiptNo" required  value="${data.receiptNo}"/>
                        </div>
                       
                        <input type="file" id="signatureUpload" accept="image/*" style="display:none" onchange="onFileSelect2(event)">
                        
                        <div style="display:flex;  " id="mother_preview">
                            <button type='button' class="add-recept" id="sltBtn" onclick="document.getElementById('signatureUpload').click()" >Change Attachment</button> 

                            <span id="preview">
                                    <img class="signature-image" src="../uploads/${data.receipt_Image}" alt="signature" style="width:250px;height:40px;" onclick="toggleZoom()">
                            </span>
                        </div>

                    <button type="button" class="save-button" onclick="updateProgramData(${data.id})" id="save-btn">Update</button>  
    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function viewProgramData(programDataId){
console.log("programDataId",programDataId)

    var data = programData.find((programDatum)=>{
        return programDatum.id == programDataId
    });

    var modals = document.querySelector('.modals');
    var modalContent = `
    
    <style>
        input{
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, transparent);
            background: var(--Foundation-White-W300, #F6F6F6);
        
        }
            

        .modal-container{
            display: none; 
            position: fixed; /* Fixed position */
            z-index: 12000; /* Make sure it appears on top of everything */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); /* Black background with opacity */
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            /* padding: 20px; */
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 500px;
            max-width: 458px;
            /* overflow-x: scroll;
            overflow-y: scroll; */
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
        background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .add-text > h3 {
            color: #FFF;
            font-family: Archivo;
            font-size: 24px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 28.8px */
            text-align: center;
        }

        .nav-btn {
        display: flex;
        width: 110px;
        height: 40px;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background: #097B48;
        border: 0;
        color: #FFF;
        font-family: Roboto;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        cursor: pointer;
        }

        .save-button{
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 19.2px */
            border: 0;
            margin-left: 110px;
            margin-top: 20px;
        }

        .add-recept{
        /* padding:10px; */
        border-color: transparent;
        background-color: transparent;
        color: #097B48;
        font-family: Inter;
        cursor: pointer;
        }

    .form_element{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    form{
        padding: 20px;
        font-family: Inter;
    }
</style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            
            <div class="add-text-header" style="display:flex; justify-content:space-between; align-item:center;">
            <button style="border:1px solid transparent; outline:none; padding:
                5px 15px; border-radius:10px;">Download <img id="userdata-option-1" class="userdata-image" src="${hompepageUrl2}/assets/images/download.png" alt="" style="height:10px; width:8px;" /></button>
                <h3>View</h3>
                
                
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
        <form id="form">
                        
                    <div  style="display:flex;justify-content:space-between">

                            <div></div>
                            <img id="userdata-option-1" class="userdata-image" src="${hompepageUrl2}/assets/images/printLogo.png" alt="" style="height:60px; width:120px;" />
                            <div></div>
                    </div>
    
                       

                <div class="form_element">
                <label for="Donor">Name of Donor</label>
                <input type="text" id="Donor" required value="${data.donor}" readonly/>
            </div>
            <div class="form_element">
                <label for="Item">Item</label>
                <input type="text" id="Item" required value="${data.item}" readonly/>
            </div>
            <div class="form_element">
                <label for="Amount">Amount</label>
                <input type="text" id="Amount" required  value="${data.amount}" readonly/>
            </div>
            <div class="form_element">
                <label for="Date">Date</label>
                <input type="date" id="Date" required  value="${data.date}" readonly/>
            </div>
            <div class="form_element">
                <label for="ReceiptNo">Receipt/Cheque Number</label>
                <input type="text" id="ReceiptNo" required  value="${data.receiptNo}" readonly/>
            </div>

                       
                        <input type="file" id="signatureUpload" accept="image/*" style="display:none" onchange="onFileSelect2(event)">
                        
                        <div style="display:flex;  " id="mother_preview">
                            <button type='button' class="add-recept" id="sltBtn" onclick="document.getElementById('signatureUpload').click()" >Change Attachment</button> 

                            <span id="preview">
                                    <img class="signature-image" src="../uploads/${data.receipt_Image}" alt="signature" style="width:250px;height:40px;" onclick="toggleZoom()">
                            </span>
                        </div>

                    
    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}
function updateProgramData(programDataId){
    var savebtn = document.getElementById('save-btn');
    var form = document.getElementById('form');
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;
     var modals = document.querySelector('.modals');
    const donor = document.getElementById('Donor').value;
    const item = document.getElementById('Item').value;
    const amount = document.getElementById('Amount').value;
    const date = document.getElementById('Date').value;
    const receiptNo = document.getElementById('ReceiptNo').value;
    
    var formData = new FormData();
    formData.append('donor', donor);
    formData.append('item', item);
    formData.append('amount', amount);
    formData.append('date', date);
    formData.append('receiptNo', receiptNo);
    formData.append('image', chosen_file2);
    formData.append('programDataId', programDataId);
   
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        var response = JSON.parse(xhttp.response);
        // for(var modal of modals){
        //     modal.style.display = 'none';
        // }

        // for(var form of forms){
        //     form.reset();
        // }
        form.reset();
        modals.style.display = 'none';
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Success', "Record updated!", 'success');
        getProgramData();
    }
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occured, try again!", 'error');
    }

    xhttp.open("POST", '../backend/request.php?function=update-ProgramData', true);
    // xhttp.open('POST', serverUrl+'?function=save-ProgramData', true);
    console.log("formData",formData )
    xhttp.send(formData);
}

function deleteProgramData(programDataId){
    swal({
        title: "Are you sure?",
        text: "This will be deleted permanently.",
        type: "warning",
        showCancelButton: true,
        showConfirmButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Delete",
        cancelButtonText: "Cancel",
        closeOnConfirm: true,
        closeOnCancel: true
      },
      function(isConfirm){
        if (isConfirm) {
            var formData = new FormData();
            formData.append('programDataId', programDataId);
            var xhttp = new XMLHttpRequest();
            xhttp.onload = function(){
                var response = JSON.parse(xhttp.response);
                if(response.success){
                    getProgramData();
                    swal('Hurray', response.success, 'success');
                }
                else{
                    swal('Sorry', response.error, 'error');
                }
            }
            xhttp.onerror = function(error){
                swal('Sorry', "An error occured, try again!", 'error');
            }
        
            xhttp.open("POST", '../backend/request.php?function=delete-ProgramData', true);
            console.log("formData", formData)
            xhttp.send(formData);
        }
      });
}


//disbursement
let inputCount = 0; 

function addInputs() {
    inputCount++;  // Increment the counter for unique IDs

    // Create a div to contain the new input fields and remove button
    const container = document.createElement('div');
    container.classList.add('input-container');

    // Create the first input element for the item
    const input1 = document.createElement('input');
    input1.type = 'text';
    input1.name = 'item[]';  // Change to 'item[]' to match the save function
    input1.id = `input1_${inputCount}`;  // Assign a unique ID
    input1.placeholder = 'Enter the Item';

    // Create the second input element for quantity
    const input2 = document.createElement('input');
    input2.type = 'text';
    input2.name = 'quantity[]';  // Change to 'quantity[]' to match the save function
    input2.id = `input2_${inputCount}`;  // Assign a unique ID
    input2.placeholder = 'Enter Quantity received';
    input2.style.marginLeft="5px";

    // Create a remove button
    const deleteText = document.createElement('span');
    deleteText.innerText = 'Delete'; // Set the text content
    deleteText.style.color = "red";  // Set text color to red
    deleteText.style.cursor = "pointer"; // Make it look like a clickable item
    deleteText.style.marginLeft = "7px"; // Add some margin for spacing
    deleteText.style.fontWeight = "400"; // Optional: make the text bold
    deleteText.style.fontSize = "12px"; // Optional: make the text bold

    // Add event listener for the click event
    deleteText.onclick = function() {
        container.remove();  // Remove the entire input block when clicked
    };

    // Append the input fields and remove button to the container
    container.appendChild(input1);
    container.appendChild(input2);
    container.appendChild(deleteText);

    // Append the container to the input-container div
    document.getElementById('input-container').appendChild(container);
}

function addDisbursementData(){
    var modals = document.querySelector('.modals');
    var modalContent = `
    
    <style>
        input{
            padding: 12px 17px;
            border-radius: 8px;
            border: 1px solid var(--Foundation-Primary-P400, #097B48);
            background: var(--Foundation-White-W300, #F6F6F6);
        
        }
            

        #input-container{
        display:flex;
        flex-wrap:wrap;
        align-items:center;
        }

        .modal-container{
            display: none; 
            position: fixed; /* Fixed position */
            z-index: 12000; /* Make sure it appears on top of everything */
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.4); /* Black background with opacity */
        }

        .modal-content {
            background-color: #fefefe; 
            position: fixed; 
            top: 50%; 
            left: 50%; 
            transform: translate(-50%, -50%); 
            /* padding: 20px; */
            border: 1px solid #888;
            width: 80%;
            max-height: 100vh; 
            max-width: 500px;
            overflow-y: scroll; 
            /* overflow-x: scroll;
            */
        }

        .close {
            color: white;
            font-size: 28px;
            font-weight: bold;
        }
        
        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .add-text-header {
        background: #097B48;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
            margin-bottom: 4px;
            height: 35px;
            color: white;
        }

        .add-text > h3 {
            color: #FFF;
            font-family: Archivo;
            font-size: 24px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 28.8px */
            text-align: center;
        }

        .nav-btn {
        display: flex;
        width: 110px;
        height: 40px;
        justify-content: center;
        align-items: center;
        border-radius: 10px;
        background: #097B48;
        border: 0;
        color: #FFF;
        font-family: Roboto;
        font-size: 17px;
        font-style: normal;
        font-weight: 400;
        cursor: pointer;
        }

        .save-button{
            display: flex;
            width: 118px;
            height: 37px;
            padding: 10px;
            justify-content: center;
            align-items: center;
            gap: 10px;
            flex-shrink: 0;
            border-radius: 10px;
            background: #097B48;
            color: #FFF;
            text-align: center;
            font-family: Archivo;
            font-size: 18px;
            font-style: normal;
            font-weight: 600;
            line-height: 120%; /* 19.2px */
            border: 0;
            margin-left: 125px;
            margin-top: 20px;
        }

        .add-recept{
        /* padding:10px; */
        border-color: transparent;
        background-color: transparent;
        color: #097B48;
        font-family: Inter;
        cursor: pointer;
        }

    .form_element{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        margin-bottom: 1.5rem;
        width: 100%;
    }

    form{
        padding: 20px;
        font-family: Inter;
    }
</style>
    <div id="myModal" class="modal-container">
        <div class="modal-content">
            
            <div class="add-text-header">
            <h3></h3>
                <h3>Add </h3>
                <span onclick="closeModal()" class="close">&times;</span>
            </div>
        <form id="form" class="dynamicForm">
                       

                       <div class="form_element">
                                <label for="Donor">Name of Receiver</label>
                                <input type="text" id="receiver" required />
                        </div>
                       <div class="form_element">
                                <label for="Item">Pin</label>
                                <input type="text" id="pin" required />
                        </div>
                            <div class="form_element">
                                <label for="Date">Date</label>
                                <input type="date" id="Date" required />
                        </div>

                       <div class="form_element">

                                 <div  style="display:flex; margin:10px 0; justify-content:space-between; align-items:center;border-bottom:1px solid gray">
                                 <h4>Item(s)</h4>
                                 <h4>Quantity</h4>
                                 </div>
                                 <div id="input-container" style="display:flex; margin:10px 0" class="input-container"></div>
                                 <button type="button" onclick="addInputs()" style="width:40%; margin-top:10px; background-color:lightgray; margin-left:100px; padding:15px; border-color:transparent;outline:none;">Add Items</button>
                        </div>
                       
                      
                    

                    <button type="button" class="save-button" onclick="saveDisbursementData()" id="save-btn">Save</button>  
    </form>

        </div>
    </div>
    `;
    if(modals){
        modals.innerHTML = modalContent;
        openModal();
    }
}

function saveDisbursementData(){
    var savebtn = document.getElementById('save-btn');
    savebtn.innerHTML = 'Saving...';
    savebtn.disabled = true;

    const receiver = document.getElementById('receiver').value;
    const pin = document.getElementById('pin').value;
    const date = document.getElementById('Date').value;

    // Correct the query selectors to match the updated input names
    const itemInputs = document.querySelectorAll('input[name="item[]"]');
    const quantityInputs = document.querySelectorAll('input[name="quantity[]"]');

    var formData = new FormData();
    formData.append('receiver', receiver);
    formData.append('pin', pin);
    formData.append('date', date);

    // Loop through item inputs and append their values to FormData
    itemInputs.forEach((itemInput, index) => {
        formData.append(`item[${index}]`, itemInput.value);
        formData.append(`quantity[${index}]`, quantityInputs[index].value);
    });

    console.log("formData",formData)

    // Log FormData for debugging
    for (let [key, value] of formData.entries()) {
        console.log(key, value);
    }

    // AJAX request (uncomment and update the URL)
    var xhttp = new XMLHttpRequest();
    xhttp.onload = function(){
        console.log('Response received:', xhttp.response);
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Success', "Record saved!", 'success');
    };
    xhttp.onerror = function(){
        savebtn.disabled = false;
        savebtn.innerHTML = "Save";
        swal('Sorry', "An error occured, try again!", 'error');
        console.error('An error occurred.');
    };

    xhttp.open("POST", '../backend/request.php?function=save-disburseData', true);
    // xhttp.open('POST', 'serverUrl?function=save-DisbursementData', true);
    xhttp.send(formData);
}

//balancesheet