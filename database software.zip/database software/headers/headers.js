if (window.location.pathname !== '/index.html') { // Adjust the path according to your setup
    document.addEventListener('DOMContentLoaded', function(){
        var admin = JSON.parse(window.sessionStorage.getItem('admin'));
        
        if (!admin) {
            window.location.href = '../index.html';
        }
    });
}
//finance dropdown
function viewDropdownItems(element){
    var path = window.location.pathname;
    if( path == '/balanceSheet/balancesheet.html' || path == '/balanceSheet/balancesheet.html' ){
        dropdownBtn = element;
        var id = element.getAttribute('id');
        var split_id = id.split('-');
        var value = split_id[0];
        dropdownElement = document.getElementById(value);
        dropdownElement.style.display = 'block';
        window.location.href = '../dashboard/dashboard.html';
    }else{
        window.location.href = '../dashboard/dashboard.html';
    }
}
function viewDropdownItem(route){
    window.location.href = route;
}
var itemsdropped = false;
function toggleFinanceCollapse(){
    var contactElement = document.getElementById('finance');
    var contactDropdownImg = document.getElementById('finance-dropdown-img');
    itemsdropped = !itemsdropped;
    if(itemsdropped){
        contactElement.style.display = 'block';
        contactDropdownImg.style.transform = "rotate(180deg)";
    }else{
        contactElement.style.display = 'none';
        contactDropdownImg.style.transform = "rotate(0deg)";
    }
}
// ensure finance dropdown remains opened
// document.addEventListener('DOMContentLoaded', function(event){
//     var path = window.location.pathname;
//     if( path == '/balanceSheet/balancesheet.html' || path == '/balanceSheet/balancesheet.html'
//      ){
//         var projectDropdownImg = document.getElementById('finance-dropdown-img');
//         var dropdownElement = document.getElementById('finance');
//         dropdownElement.style.display = 'block';
//         // contactdropdown.style.color = '#82bf25';
        
//     }else{

//     }
    
// });

const topHeader = document.getElementById('top-header');
const headerHide = document.getElementById('header-hide');

let headerText = ''
if(headerHide){
     headerText = headerHide.innerText;
}

const topHeaderContent = 
` <nav class="top-nav2">
            <img src="../assets/images/ehi-logo.png" alt="" class="ehi-logo">
            <p class="top-text">${headerText}</p>
            <button class="sign-out-button" onclick="signOut()">Sign Out</button>
        </nav>
`
if(topHeader){
    topHeader.innerHTML = topHeaderContent;
}

const leftBar = document.getElementById('left-bar');

const leftBarContent = ` <ul class="leftbar-list">
                <li >
                    <a href="../dashboard/dashboard.html" class="dashboard-list">
                        <img src="../assets/images/dashboard-icon.png" alt="" class="dashboard-icon">
                        Dashboard
                    </a>
                </li>
                <li >
                    <a href="../userdata/userdata.html" class="anchor-list">
                        User Data
                    </a>
                </li>
                <li >
                     <a href="../programdata/programdata.html" class="anchor-list">
                        Programe Data 
                        
                    </a>

                </li>
                <li >
                    <a href="../Disbursment/disbursement.html" class="anchor-list">
                        Disbursement 
                    </a>
                </li>
                <li >

                        <a href="javascript:void(0)" class="anchor-list" >


                        <span style="display:flex; gap:5px">
                         <p id="contact-dropdown" onclick="viewDropdownItems(this)">Finance </p>

                        <div onclick="toggleFinanceCollapse()" >
                        <img class="search-dropdown-icon" src="../assets/images/dropdown-icon.png" alt="" id="finance-dropdown-img">
                        </div> 
</span>
                         <div id="finance" class="dropdown-container" style="display:none !important; margin-left:5px">

                        <div class="dropdown-item" onclick="viewDropdownItem('../balanceSheet/balancesheet.html')" syle=" cursor: pointer;"><span class="dropdown-text">Balance Sheet</span>
                        </div>
                       

                        <div class="dropdown-item" onclick="viewDropdownItem('../balanceSheet/balancesheet.html')" syle=" cursor: pointer;"><span class="dropdown-text">Payment & Receipt</span>
                        </div>
                        
                        </div>
                        </a>
                </li>
                <li >
                    <a href="../dashboard/dashboard.html" class="anchor-list">
                        Report
                    </a>
                </li>
                <li >
                    <a href="../dashboard/dashboard.html" class="anchor-list">
                        Segregation
                    </a>
                </li>
            </ul>
`

if(leftBar){
    leftBar.innerHTML =leftBarContent
}

const footer = document.getElementById('footer');

const footerContent = `   <div class="first-footer">
            <img class="hans-logo" src="../assets/images/hans-logo.png" alt="hans-logo">
            <p class="footer-copyright">Powered by Hans Technology </p>

        </div>
        <div class="first-footer">
            <p class="footer-copyright">copyright <span><img src="../assets/images/Vector.png" alt=""></span>ehicentre2024</p>
        </div>
`
if(footer){
    footer.innerHTML = footerContent;
}

function signOut(){
   
    window.sessionStorage.removeItem('admin');
    window.location.href = '../index.html';
}



